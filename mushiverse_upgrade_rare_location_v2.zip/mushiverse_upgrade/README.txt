ムシバース 追加アップデート（2026-10-21）

内容：
start.html : 初心者ガイド・共有・iPhoneホーム画面追加
rarity.html: ★1〜★5の個人用レア度メモ、保全状況の説明、希少種保護の注意

導入：GitHubリポジトリ mushiverse のルートに2つのHTMLファイルをアップロードしてください。
公開先：
https://rikuto06100102-tech.github.io/mushiverse/start.html
https://rikuto06100102-tech.github.io/mushiverse/rarity.html

重要：
・既存index.htmlにはまだリンクを追加していません。
・AIでの保全状況の自動判定は未実装です。既存AIの判定結果は種名候補と確信度などであり、保全情報は返しません。
・AI判定に保全状況を加えるには、分類群の同定結果と信頼できるレッドリストデータを照合するバックエンドが必要です。
・レア度の星は公式な絶滅危惧度ではありません。
・GitHub連携の書込権限が403だったため自動反映できず、今回は手動アップロード用ファイルです。

追加：location.html（2026-10-21）
現在地の手動取得とOpenStreetMap埋め込み表示を追加しました。
GitHubリポジトリのルートに location.html もアップロードしてください。
公開先：https://rikuto06100102-tech.github.io/mushiverse/location.html
位置情報はユーザー操作時のみ取得し、アプリ側では保存しません。ただし外部地図サービスへ座標が送られます。
既存 index.html へのリンク追加は未実施です。近隣スポットの自動推薦や希少種地点のマスキングは未実装です。
